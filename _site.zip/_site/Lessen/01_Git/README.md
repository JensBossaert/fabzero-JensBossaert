# Les 01: Learn Git - Setup Project

We leren aan wat git is, en passen het toe op deze template.

source: `{{ page.path }}`
