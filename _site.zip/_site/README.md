# FabZero-traject Jens Bossaert
[![logo](https://ingegnomakerspace.github.io/inclusievekets/assets/images/logo.svg)][fabzero]

Hallo! Mijn naam is __Jens Bossaert__. Op deze GitHubpagina houd ik de lessenreeks FabZero bij. Dat is een overzicht van de geziene "theorie" (lees: korte overzichten van de les met handige links en informatie), de resultaten van de opdrachten voor thuis, en de vooruitgang van mijn uiteindelijke "afstudeerproject".

_Met dank aan [Ingegno](https://ingegno.be/)!_

<!-- ![notapieceofcake]({{ site.baseurl }}/assets/cake.png "Cake") -->

## License
_Template based on [jekyll-rtd-theme](https://github.com/rundocs/jekyll-rtd-theme). The theme is available as open source under the terms of the MIT License. The content is Creatieve Commons, non-commercial._

[fabzero]: https://ingegnomakerspace.github.io/inclusievekets/deelnemers
