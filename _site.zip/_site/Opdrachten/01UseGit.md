# Git gebruiken

Opdracht: Gebruik Git om verslag bij te houden van je vooruitgang.

Stuur de link naar deze repo naar de FabZero verantwoordelijke.

source: `{{ page.path }}`
